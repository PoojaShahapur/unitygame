﻿namespace BehaviorLibrary.Components
{
    public class LeafComponent : BehaviorComponent
    {
    }
}