﻿using UnityEngine;
using UnitySteer.Behaviors;

namespace SDK.Lib
{
    /**
     * @brief 凡是 BehaviorTree 之外的 AI 逻辑都写在这里
     */
    public class AIController
    {
        protected Biped m_vehicle;
        protected Radar m_radar;                // 每一个人身上有一个雷达

        public AIController()
        {
            
        }

        public Biped vehicle
        {
            get
            {
                return m_vehicle;
            }
            set
            {
                m_vehicle = value;
            }
        }

        public Radar radar
        {
            get
            {
                return m_radar;
            }
            set
            {
                m_radar = value;
            }
        }

        public void OnTick(float delta)
        {
            if(m_radar != null)
            {
                m_radar.UpdateRadar();      // 更新雷达数据
            }
        }

        public void initControl(SkinAniModel skinAniModel)
        {
            m_radar = new Radar();
            m_vehicle = new Biped();

            //m_vehicle.Radar = m_radar;
            //m_vehicle.ArrivalRadius = 1;
            //m_vehicle.AllowedMovementAxes = new Vector3(1, 0, 1);
            //m_vehicle.MaxSpeed = 10;
            //m_vehicle.setSpeed(5);
            //m_vehicle.initOwner(skinAniModel.rootGo);

            //m_radar.Vehicle = m_vehicle;
            //m_radar.initAwake();
            m_radar.DetectionRadius = 100;
        }
    }
}