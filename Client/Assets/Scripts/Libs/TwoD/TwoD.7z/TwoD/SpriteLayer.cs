﻿namespace SDK.Lib
{
    public class SpriteLayer : AuxComponent
    {

    }
}