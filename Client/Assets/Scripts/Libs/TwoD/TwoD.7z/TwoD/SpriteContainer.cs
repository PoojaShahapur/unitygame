﻿namespace SDK.Lib
{
    public class SpriteContainer : AuxComponent
    {

    }
}