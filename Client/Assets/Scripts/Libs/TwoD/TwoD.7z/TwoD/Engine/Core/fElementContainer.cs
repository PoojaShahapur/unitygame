namespace SDK.Lib
{
	public class fElementContainer : AuxComponent
	{
		public string fElementId;
		public fRenderableElement fElement;
	}
}