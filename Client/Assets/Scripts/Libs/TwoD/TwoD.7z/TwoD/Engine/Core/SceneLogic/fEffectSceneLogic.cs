namespace SDK.Lib
{
	public class fEffectSceneLogic 
	{
		// 进入新的单元格子处理   
		public static void processNewCellEffect(fScene scene, EffectEntity effect, bool forceReset = false)
		{
			// KBEN: 是否更改 Floor 
			//effect.updateFloorInfo(EntityCValue.TEfffect);
		}
		
		// 移动处理  
		public static void renderEffect(fScene scene, EffectEntity effect)
		{
			scene.renderEngine.updateEffectPosition(effect);
		}
	}
}