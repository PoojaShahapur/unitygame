namespace SDK.Lib
{
	public interface fEngineSceneController
	{
        void assignScene(fScene scene);

        void enable();
		
		void disable();
	}
}