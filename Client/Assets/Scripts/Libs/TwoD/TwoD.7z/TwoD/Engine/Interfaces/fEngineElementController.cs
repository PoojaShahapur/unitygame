namespace SDK.Lib
{
	public interface fEngineElementController
	{
		void assignElement(fElement element);
        void enable();
        void disable();
	}
}