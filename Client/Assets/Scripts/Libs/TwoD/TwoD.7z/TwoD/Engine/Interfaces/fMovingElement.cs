namespace SDK.Lib
{
	public interface fMovingElement
	{
	
	}
}