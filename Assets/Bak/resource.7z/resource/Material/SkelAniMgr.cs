namespace SDK.Lib
{
    public class SkelAniMgr
    {
        public SkelAniMgr()
        {

        }
    }
}