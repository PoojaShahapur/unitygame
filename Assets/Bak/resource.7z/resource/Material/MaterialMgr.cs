using System.Collections.Generic;
using UnityEngine;

namespace SDK.Lib
{
    public class MaterialMgr
    {
        public Dictionary<MaterialID, Material> m_ID2MatDic = new Dictionary<MaterialID, Material>();

        public MaterialMgr()
        {

        }

        // ���� Material 
        public void Load()
        {

        }
    }
}