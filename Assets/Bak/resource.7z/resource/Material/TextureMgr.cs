namespace SDK.Lib
{
    public class TextureMgr
    {
        public TextureMgr()
        {

        }
    }
}