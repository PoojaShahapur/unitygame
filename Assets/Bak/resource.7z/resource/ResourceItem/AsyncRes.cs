﻿using SDK.Common;
using System;

namespace SDK.Lib
{
    public class AsyncRes : Res
    {
        public AsyncRes()
        {
            
        }
    }
}