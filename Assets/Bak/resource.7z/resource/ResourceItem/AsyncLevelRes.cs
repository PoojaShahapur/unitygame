﻿using SDK.Common;
using System;
namespace SDK.Lib
{
    class AsyncLevelRes : AsyncRes
    {
        public AsyncLevelRes()
        {
            
        }
    }
}